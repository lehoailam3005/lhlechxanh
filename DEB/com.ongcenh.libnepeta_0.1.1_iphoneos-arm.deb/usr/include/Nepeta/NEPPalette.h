@interface NEPPalette : NSObject
    @property (nonatomic, retain) UIColor *background;
    @property (nonatomic, retain) UIColor *primary;
    @property (nonatomic, retain) UIColor *secondary;
    @property (nonatomic, retain) UIColor *detail;
@end