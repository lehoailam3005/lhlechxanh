var twentyfourhour = true; 
var pad = true; 
var textcolor = "#fff"; // Màu Lịch
var logo = "2"; // chọn "1" đến "4"
var IconSet = "2"; // chọn "1" hoặc "2"
