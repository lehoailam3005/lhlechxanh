#import <UIKit/UIKit.h>

@interface BTBCustomModuleBackgroundView : UIView
- (void)viewSetContinuousCornerRadius:(CGFloat)radius;
@end
