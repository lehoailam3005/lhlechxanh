var twentyfour = false; 
var padzero = false; 
var refresh = 5000; 
var weathercode = "CAXX0501"; // go to weather.com to get your city's code, the code is in the url
var celsius = false; 
var gpsswitch = true; // must use widget weather xml if set to true
var refreshrate = 30; 
var language = "en"; // en, cz, it, sp, de, fr, zh
