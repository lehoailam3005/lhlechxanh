#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>

#import "./HPSRootListController.h"

@interface HPSSubListController : HPSRootListController
@end
