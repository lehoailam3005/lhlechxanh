mv /usr/lib/TweakInject/WatchdogLite.dylib /usr/lib/TweakInject/WatchdogLite.dylib.no
mv /usr/lib/TweakInject/Watchdog.dylib /usr/lib/TweakInject/Watchdog.dylib.no