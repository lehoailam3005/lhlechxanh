var RandomRipple = "5000"; // 5000 is 5 seconds, so 10 seconds will be 10000, others you can calculate it :) and 9999999 if you don't want random splashes.
var RandomRippleAmount = "3"; // how many splashes do you wanna see every RandomRipple seconds? Don't make it too high, it may lag your device
var WidgetResolution = "1"; // the resolution of widget. You could say quality too. 0 for best quality but more CPU usage and battery and 2 for the lowest. 1 is default.
var SRadius = "0.005"; // radius of splashes. 0.0001 is smallest radius and 0.01 for biggest radius. Default is 0.005
var SVelo = "0.99"; // 0 will look sticky and max 1 will look more smokey (try yourself out cuz it's hard to explain this one) 0.99 is default.
var SDen = "0.98"; // 0 will disappear quick and 1(max) will disappear slowest. 0.98 is default.
