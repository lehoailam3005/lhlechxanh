
//------------------------- MUSIC FUNCTIONS ---------------------------
function checkMusic(){
	if (isplaying === 1) {
		document.getElementById('playPause').classList.remove("zeek-buttonplay");
		document.getElementById('playPause').classList.add("zeek-buttonpause");
	}else{
		document.getElementById('playPause').classList.remove("zeek-buttonpause");
		document.getElementById('playPause').classList.add("zeek-buttonplay");
	}
	
	if(title === "(null)"){
		document.getElementById('_artist').innerHTML = '';
		document.getElementById('_title').innerHTML = '';
		if(muP === 1){
			document.getElementById('_musCont').style.display = 'none';
			document.getElementById('musicArtGen').style.display = 'none';
			if(mus.classList.contains('open')){
				openWid();
			}
		}
	}else{
		document.getElementById('_artist').innerHTML = artist;
		document.getElementById('_title').innerHTML = title;
		if(muP === 1){
			document.getElementById('_musCont').style.display = 'block';
			document.getElementById('musicArtGen').style.display = 'block';
		}
		if (checkOverflow(document.getElementById('_title')) === true){
			document.getElementById('_title').classList.add("marquee");
		} else {
			document.getElementById('_title').classList.remove("marquee");
		}
	}
	
	
	if(album === "(null)"){
		//document.getElementById('_album').innerHTML = "";
		document.getElementById('musicArt').src = 'img/note.PNG';
		if(one === 1){
			document.getElementById('musicArtGen').src = 'img/note.PNG';
		}
	}else{
		//document.getElementById('_album').innerHTML = album;
		
		var xhr = new XMLHttpRequest();
		xhr.open('HEAD', "file:///var/mobile/Documents/Artwork.jpg", false);
		xhr.send();
		if (xhr.status === "404") {
			document.getElementById('musicArt').src = 'img/note.PNG';
			if(one === 1){
				document.getElementById('musicArtGen').src = 'img/note.PNG';
			}
		}else{
			document.getElementById('musicArt').src = "file:///var/mobile/Documents/Artwork.jpg?" + (new Date()).getTime();
			if(one === 1){
				document.getElementById('musicArtGen').src = "file:///var/mobile/Documents/Artwork.jpg?" + (new Date()).getTime();
			}
		}
	}
	
}

function checkOverflow(el) {
	var curOverflow = el.style.overflow;
	if ( !curOverflow || curOverflow === "visible" ){
		el.style.overflow = "hidden"; 
	}
	var isOverflowing = el.clientWidth < el.scrollWidth || el.clientHeight < el.scrollHeight;
	el.style.overflow = curOverflow;
	return isOverflowing; 
} 


function playPause() {
	if ( document.getElementById('playPause').classList.contains("zeek-buttonplay")){ 
		document.getElementById('playPause').classList.remove("zeek-buttonplay");
		document.getElementById('playPause').classList.add("zeek-buttonpause");
	}else{ 
		document.getElementById('playPause').classList.remove("zeek-buttonpause");
		document.getElementById('playPause').classList.add("zeek-buttonplay");
	}
	window.location = 'xeninfo:playpause';
	document.getElementById('playPause').style.opacity = 0.8;
	setTimeout(function (){
		document.getElementById('playPause').style.opacity = 1;
	}, 200);
}
		
function next() {
	window.location = 'xeninfo:nexttrack';
	document.getElementById('next').style.opacity = 0.8;
	setTimeout(function (){
		document.getElementById('next').style.opacity = 1;
	}, 200);
}
			
function prev() {
	window.location = 'xeninfo:prevtrack';
	document.getElementById('prev').style.opacity = 0.8;
	setTimeout(function (){
		document.getElementById('prev').style.opacity = 1;
	}, 200);
}

