var musicTileMaker = {
    musicData: function(params) {
        let icon = "";
        let mediaInfo = "";
        if(params.newData.isStopped || !params.newData.isPlaying || params.newData.nowPlayingApplication.identifier !== params.identifier) {
            if(config.disableWidgetIcons) {
                icon = `<span class='custom icon' style='background-image: url(${params.appData.applicationForIdentifier(params.identifier).icon})'></span>`;
            } else {
                icon = globalParams.mifIcons[params.identifier] ? 
                `<span class="${globalParams.mifIcons[params.identifier]} icon slide"></span>` 
                : `<span class='custom icon' style='background-image: url(${params.appData.applicationForIdentifier(params.identifier).icon})'></span>`
            } 
        } else {
            mediaInfo = `<div id='artwork' class='slide' style="background-image:url('${params.newData.nowPlaying.artwork}')"></div>
                         <div id='musicData' class='slide'>
                             <div id='musicArtist'>${params.newData.nowPlaying.artist}</div>
                             <div id='musicTitle'>${params.newData.nowPlaying.title}</div>
                         </div>
                        `
        }
        
        let badge = params.appData.applicationForIdentifier(params.identifier).badge === "" ? "" : `<span class="badge-top">${params.appData.applicationForIdentifier(params.identifier).badge}</span>`;
        let name = params.appData.applicationForIdentifier(params.identifier).name;
        
        return `
                ${icon}
                ${mediaInfo}
                <span class="branding-bar">${name}</span>
                ${badge}
                `
    },
    init: function(params) {
        let content = this.musicData(params);
        let color = params.color === "bg-custom" ? "bg-custom bg-blur" : params.color + " bg-blur";
        if(!document.getElementById(params.identifier)) {
            const htmlString = `<div name='${params.appData.applicationForIdentifier(params.identifier).name}' id="${params.identifier}" data-size="${params.tileSize}" data-role="tile" class="leTile leMusicTile ${color}" data-effect="slide-down">
                                ${content}
                            </div>`;
            loadWidget.startMenu.innerHTML += htmlString;
        } else {
            document.getElementById("com.apple.mobiletimer").innerHTML = content;
        }
    } 
}