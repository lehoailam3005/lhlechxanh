var startScreenMaker = {
    dragMode: false,
    launchApp: function(identifier) {
        if(!appDrawerMaker.invokeMenu && document.getElementById(identifier).classList.contains("leTile") && !this.dragMode) {
            api.apps.launchApplication(identifier);
        }
    },
    tapHoldOnIcon: function(el) {
        if(el.classList.contains("leTile") && !this.dragMode) {
            appDrawerMaker.invokeMenu = true;
            appDrawerMaker.checkIfMenuExists();
            el.classList.add("selected");
            startScreenMaker.makeMenu(el);
        }
    },
    makeMenu: function(element) {
        menu.init({
            id: element.id + ".Menu",
            message: api.apps.applicationForIdentifier(element.id).name,
            menuItems: [
                {
                    id: "tilePosition",
                    title: "Di chuyển Ô",
                    callback: function() {
                        startScreenMaker.dragMode = true;
                        let newDiv = domMaker.init({
                            type: "div",
                            className: "drag-mode",
                            innerHTML: "Chế độ kéo đã được kích hoạt"
                        });
                        let cancelButton = document.getElementById("cancelEditing");
                        cancelButton.classList.remove("hide");
                        cancelButton.addEventListener("click", () => location.href = location.href);
                        domMaker.domAppender({
                            div: loadWidget.startMenu,
                            children: [newDiv]
                        })
                        new Sortable(loadWidget.startMenu, {
                            draggable: ".leTile",
                            removeCloneOnHide: true,
                            onEnd: function(e) {
                                localstore.changeAppPosition("metroTiles", e.oldIndex, e.newIndex);
                                window.location.href = window.location.href;
                            }
                        });
                    }
                },
                {
                    id: "tileColor",
                    title: "Màu sắc Ô",
                    callback: function() {
                        setTimeout(() => {
                            menu.init({
                                id: "tileColor",
                                message: "Tuỳ chỉnh màu Ô bạn muốn?",
                                menuItems: startScreenMaker.changeTileColor(element.id)
                            });
                        }, 400);
                    }
                },
                {
                    id: "tileSize",
                    title: "Kích cỡ Ô",
                    callback: function() {
                        setTimeout(() => {
                            menu.init({
                                id: element.id + "TileSize",
                                message: "Tuỳ chỉnh kích cỡ Ô",
                                menuItems: startScreenMaker.changeTileSize(element.id)
                            });
                        }, 400);
                    }
                },
                {
                    id: "tileSize",
                    title: "Đặt lại màu (Ô đã chọn)",
                    callback: function() {
                        let index = localstore["metroTiles"].map((e) => e.identifier).indexOf(element.id);
                        let tileSize = localstore["metroTiles"][index].tileSize;
                        appDrawerMaker.invokeMenu = false;
                        localstore.modifyAppObj("metroTiles", element.id, {identifier: element.id, tileSize: tileSize, color: "bg-custom"});
                        startScreenMaker.init(api.apps, api.media);
                    }
                },
                {
                    id: "tileSize",
                    title: "Đặt lại màu (Tất cả các Ô)",
                    callback: function() {
                        appDrawerMaker.invokeMenu = false;
                        for(let i = 0 ; i < localstore["metroTiles"].length; i++) {
                            localstore.modifyAppObj("metroTiles", localstore["metroTiles"][i].identifier, {identifier: localstore["metroTiles"][i].identifier, tileSize: localstore["metroTiles"][i].tileSize, color: "bg-custom"});
                        }
                        startScreenMaker.init(api.apps, api.media);
                    }
                },
                {
                    id: "addApp",
                    title: "Xoá Ô",
                    callback: function() {
                        appDrawerMaker.invokeMenu = false;
                        localstore.removeAppObj("metroTiles", element.id);
                        startScreenMaker.init(api.apps, api.media);
                    }
                },
                {
                    id: "closeMenu",
                    title: "Huỷ",
                    callback: function() {
                        appDrawerMaker.invokeMenu = false;
                    }
                }
            ]
        });
    },
    changeTileColor: function(id) {
        let tileColors = ["bg-custom", "bg-lime", "bg-green", "bg-emerald", "bg-blue", "bg-teal", "bg-cyan", "bg-cobalt", "bg-indigo", "bg-violet", "bg-pink", "bg-magenta", "bg-crimson", "bg-red", "bg-orange", "bg-amber", "bg-yellow", "bg-brown", "bg-olive", "bg-steel", "bg-mauve", "bg-taupe", "bg-gray"];
        let menuItems = [];
        menuItems.push({id: "closeColorMenu", title: "X", callback: function(){}});
        for(let i = 0; i < tileColors.length; i++) {
            let index = localstore["metroTiles"].map((e) => e.identifier).indexOf(id);
            let tileSize = localstore["metroTiles"][index].tileSize;
            let menuItem = {
                id: tileColors[i],
                title: "",
                callback: function() {
                    appDrawerMaker.invokeMenu = false;
                    localstore.modifyAppObj("metroTiles", id, {identifier: id, tileSize: tileSize, color: tileColors[i]});
                    startScreenMaker.init(api.apps, api.media);
                }
            }
            menuItems.push(menuItem);
        }
        return menuItems;
    },
    changeTileSize: function(id) {
        let tileSizes = ["Nhỏ", "Trung bình", "Rộng", "To"];
        let menuItems = [];
        for(let i = 0; i < tileSizes.length; i++) {
            let index = localstore["metroTiles"].map((e) => e.identifier).indexOf(id);
            let tileSize = localstore["metroTiles"][index].tileSize;
            let tileColor = localstore["metroTiles"][index].color;
            if(tileSizes[i] === tileSize) {
                continue;
            } else {
                let menuItem = {
                    id: tileSizes[i],
                    title: tileSizes[i],
                    callback: function() {
                        appDrawerMaker.invokeMenu = false;
                        localstore.modifyAppObj("metroTiles", id, {identifier: id, tileSize: tileSizes[i], color: tileColor});
                        startScreenMaker.init(api.apps, api.media);
                    }
                }
                menuItems.push(menuItem);
            }
        }
        menuItems.push({id: "closeMenu", title: "Huỷ", callback: function(){}});
        return menuItems;
    },
    init: function(newData, musicData) {
        loadWidget.startMenu.innerHTML = "";
        api.fs.exists('/var/mobile/Documents/' + localstore.storageName + '.json').then((exists) => {
            if(exists) {
                loadWidget.startMenu.innerHTML = "";
                let cachedApps = localstore["metroTiles"];
                for(let i = 0; i < cachedApps.length; i++) {
                    let appID = cachedApps[i].identifier;
                    if((config.disableLiveTiles || cachedApps[i].tileSize === "small") && (!musicData.isPlaying || musicData.isStopped)) {
                        tileMaker.init({
                            newData: newData,
                            color: cachedApps[i].color,
                            identifier: appID,
                            size: cachedApps[i].tileSize
                        })
                    } else {
                        switch(appID) {
                            case "com.apple.Preferences":
                                if(config.disableSettingsLive) {
                                    tileMaker.init({
                                        newData: newData,
                                        color: cachedApps[i].color,
                                        identifier: appID,
                                        size: cachedApps[i].tileSize
                                    });
                                } else {
                                    settingsTileMaker.init({
                                        color: cachedApps[i].color,
                                        tileSize: cachedApps[i].tileSize,
                                        newData: api.system
                                    });
                                }
                                break;
                            case "com.apple.mobiletimer":
                                if(config.disableClockLive) {
                                    tileMaker.init({
                                        newData: newData,
                                        color: cachedApps[i].color,
                                        identifier: appID,
                                        size: cachedApps[i].tileSize
                                    });
                                } else {
                                    clockTileMaker.init({
                                        color: cachedApps[i].color,
                                        tileSize: cachedApps[i].tileSize
                                    });
                                }
                                break;
                            case "com.apple.mobilecal":
                                if(config.disableCalendarLive) {
                                    tileMaker.init({
                                        newData: newData,
                                        color: cachedApps[i].color,
                                        identifier: appID,
                                        size: cachedApps[i].tileSize
                                    });
                                } else {
                                    calendarTileMaker.init({
                                        color: cachedApps[i].color,
                                        tileSize: cachedApps[i].tileSize
                                    });
                                }
                                break;
                            case "com.apple.weather":
                                if(config.disableWeatherLive) {
                                    tileMaker.init({
                                        newData: newData,
                                        color: cachedApps[i].color,
                                        identifier: appID,
                                        size: cachedApps[i].tileSize
                                    });
                                } else {
                                    weatherTileMaker.init({
                                        newData: api.weather,
                                        color: cachedApps[i].color,
                                        tileSize: cachedApps[i].tileSize
                                    });
                                }
                                break;
                            case "com.apple.Music":
                                if(config.disableMusicLive) {
                                    tileMaker.init({
                                        newData: newData,
                                        color: cachedApps[i].color,
                                        identifier: appID,
                                        size: cachedApps[i].tileSize
                                    });
                                } else {
                                    musicTileMaker.init({
                                        appData: newData,
                                        newData: musicData,
                                        identifier: appID,
                                        color: cachedApps[i].color,
                                        tileSize: cachedApps[i].tileSize
                                    });
                                }
                                break;
                            case "com.spotify.client": 
                                if(config.disableMusicLive) {
                                    tileMaker.init({
                                        newData: newData,
                                        color: cachedApps[i].color,
                                        identifier: appID,
                                        size: cachedApps[i].tileSize
                                    });
                                } else {
                                    musicTileMaker.init({
                                        appData: newData,
                                        newData: musicData,
                                        identifier: appID,
                                        color: cachedApps[i].color,
                                        tileSize: cachedApps[i].tileSize
                                    });
                                }
                                break;
                            case "com.soundcloud.TouchApp": 
                                if(config.disableMusicLive) {
                                    tileMaker.init({
                                        newData: newData,
                                        color: cachedApps[i].color,
                                        identifier: appID,
                                        size: cachedApps[i].tileSize
                                    });
                                } else {
                                    musicTileMaker.init({
                                        appData: newData,
                                        newData: musicData,
                                        identifier: appID,
                                        color: cachedApps[i].color,
                                        tileSize: cachedApps[i].tileSize
                                    });
                                }
                                break;
                            case "com.tunein.TuneInRadio": 
                                if(config.disableMusicLive) {
                                    tileMaker.init({
                                        newData: newData,
                                        color: cachedApps[i].color,
                                        identifier: appID,
                                        size: cachedApps[i].tileSize
                                    });
                                } else {
                                    musicTileMaker.init({
                                        appData: newData,
                                        newData: musicData,
                                        identifier: appID,
                                        color: cachedApps[i].color,
                                        tileSize: cachedApps[i].tileSize
                                    });
                                }
                                break;
                            case "com.google.ios.youtubemusic":
                                if(config.disableMusicLive) {
                                    tileMaker.init({
                                        newData: newData,
                                        color: cachedApps[i].color,
                                        identifier: appID,
                                        size: cachedApps[i].tileSize
                                    });
                                } else {
                                    musicTileMaker.init({
                                        appData: newData,
                                        newData: musicData,
                                        identifier: appID,
                                        color: cachedApps[i].color,
                                        tileSize: cachedApps[i].tileSize
                                    });
                                }
                                break;
                            case "com.audiomack.iphone":
                                if(config.disableMusicLive) {
                                    tileMaker.init({
                                        newData: newData,
                                        color: cachedApps[i].color,
                                        identifier: appID,
                                        size: cachedApps[i].tileSize
                                    });
                                } else {
                                    musicTileMaker.init({
                                        appData: newData,
                                        newData: musicData,
                                        identifier: appID,
                                        color: cachedApps[i].color,
                                        tileSize: cachedApps[i].tileSize
                                    });
                                }
                                break;
                            case "com.aspiro.TIDAL": 
                                if(config.disableMusicLive) {
                                    tileMaker.init({
                                        newData: newData,
                                        color: cachedApps[i].color,
                                        identifier: appID,
                                        size: cachedApps[i].tileSize
                                    });
                                } else {
                                    musicTileMaker.init({
                                        appData: newData,
                                        newData: musicData,
                                        identifier: appID,
                                        color: cachedApps[i].color,
                                        tileSize: cachedApps[i].tileSize
                                    });
                                }
                                break;
                            case "com.deezer.Deezer":
                                if(config.disableMusicLive) {
                                    tileMaker.init({
                                        newData: newData,
                                        color: cachedApps[i].color,
                                        identifier: appID,
                                        size: cachedApps[i].tileSize
                                    });
                                } else {
                                    musicTileMaker.init({
                                        appData: newData,
                                        newData: musicData,
                                        identifier: appID,
                                        color: cachedApps[i].color,
                                        tileSize: cachedApps[i].tileSize
                                    });
                                }
                                break;
                            case "com.til.gaana":
                                if(config.disableMusicLive) {
                                    tileMaker.init({
                                        newData: newData,
                                        color: cachedApps[i].color,
                                        identifier: appID,
                                        size: cachedApps[i].tileSize
                                    });
                                } else {
                                    musicTileMaker.init({
                                        appData: newData,
                                        newData: musicData,
                                        identifier: appID,
                                        color: cachedApps[i].color,
                                        tileSize: cachedApps[i].tileSize
                                    });
                                }
                                break;
                            case "com.Saavn.Saavn":
                                if(config.disableMusicLive) {
                                    tileMaker.init({
                                        newData: newData,
                                        color: cachedApps[i].color,
                                        identifier: appID,
                                        size: cachedApps[i].tileSize
                                    });
                                } else {
                                    musicTileMaker.init({
                                        appData: newData,
                                        newData: musicData,
                                        identifier: appID,
                                        color: cachedApps[i].color,
                                        tileSize: cachedApps[i].tileSize
                                    });
                                }
                                break;
                            case "com.amazon.mp3.AmazonCloudPlayer":
                                if(config.disableMusicLive) {
                                    tileMaker.init({
                                        newData: newData,
                                        color: cachedApps[i].color,
                                        identifier: appID,
                                        size: cachedApps[i].tileSize
                                    });
                                } else {
                                    musicTileMaker.init({
                                        appData: newData,
                                        newData: musicData,
                                        identifier: appID,
                                        color: cachedApps[i].color,
                                        tileSize: cachedApps[i].tileSize
                                    });
                                }
                                break;
                            case "com.audible.iphone":
                                if(config.disableMusicLive) {
                                    tileMaker.init({
                                        newData: newData,
                                        color: cachedApps[i].color,
                                        identifier: appID,
                                        size: cachedApps[i].tileSize
                                    });
                                } else {
                                    musicTileMaker.init({
                                        appData: newData,
                                        newData: musicData,
                                        identifier: appID,
                                        color: cachedApps[i].color,
                                        tileSize: cachedApps[i].tileSize
                                    });
                                }
                                break;
                            case "com.feelthemusi.musi":
                                if(config.disableMusicLive) {
                                    tileMaker.init({
                                        newData: newData,
                                        color: cachedApps[i].color,
                                        identifier: appID,
                                        size: cachedApps[i].tileSize
                                    });
                                } else {
                                    musicTileMaker.init({
                                        appData: newData,
                                        newData: musicData,
                                        identifier: appID,
                                        color: cachedApps[i].color,
                                        tileSize: cachedApps[i].tileSize
                                    });
                                }
                                break;
                            default: 
                                tileMaker.init({
                                    newData: newData,
                                    color: cachedApps[i].color,
                                    identifier: appID,
                                    size: cachedApps[i].tileSize
                                })
                                break;
                        }
                    }
                }
            } else {
                loadWidget.startMenu.innerHTML = "";
                let pageContainer = document.getElementById("pageContainer");
                pageContainer.scroll({
                    left: 500,
                    behavior: "smooth"
                });
            }
        });
    }
}

api.apps.observeData((newData) => {
    startScreenMaker.init(newData, api.media);
});
api.weather.observeData((newData) => {
    if(document.getElementById("weather1")) {
        weatherTileMaker.init({
            newData: newData
        });
    }
});
api.media.observeData((newData) => {
    startScreenMaker.init(api.apps, newData);
});
api.system.observeData((newData) => {
    if(document.getElementById("deviceName")) {
        settingsTileMaker.init({
            newData: newData
        });
    }
})