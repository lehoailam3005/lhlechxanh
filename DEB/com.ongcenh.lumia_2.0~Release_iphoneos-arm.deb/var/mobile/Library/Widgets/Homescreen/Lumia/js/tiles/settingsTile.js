var settingsTileMaker = {
    settingsData: function(newData) {
        let icon = `<span class='custom icon slide' style='background-image: url(${api.apps.applicationForIdentifier("com.apple.Preferences").icon})'></span>`;
        const content = `${icon}
                        <div id="systemVersion" class="slide">iOS ${newData.systemVersion}</div>
                        <span class="branding-bar">${api.apps.applicationForIdentifier("com.apple.Preferences").name}</span>`;
        return content;
    },
    init: function(params) {
        let content = this.settingsData(params.newData);
        let color = params.color === "bg-custom" ? "bg-custom bg-blur" : params.color + " bg-blur";
        if(!document.getElementById("com.apple.Preferences")) {
            const htmlString = `<div name="${api.apps.applicationForIdentifier("com.apple.Preferences").name}" id="com.apple.Preferences" data-size="${params.tileSize}" data-role="tile" class="leTile leClockTile ${color}" data-effect="slide-down">
                                ${content}
                            </div>`;
            loadWidget.startMenu.innerHTML += htmlString;
        } else {
            document.getElementById("com.apple.Preferences").innerHTML = content;
        }
    }
}