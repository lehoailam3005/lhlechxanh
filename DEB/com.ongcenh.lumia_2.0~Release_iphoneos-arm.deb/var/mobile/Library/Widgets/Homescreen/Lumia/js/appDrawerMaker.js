var appDrawerMaker = {
    allApplications: api.apps.allApplications,
    invokeMenu: false,
    movedWhilePressing: false,
    isSearching: false,
    searchEvent: function(e) {
        appsContainer = document.getElementById("allApps");
        if(e.target.value.length > 0 || e.target.value) {
            appDrawerMaker.isSearching = true;
            const searchString = e.target.value.toLowerCase();
            const filteredApps = this.allApplications.filter((app) => {
                return (app.name.toLowerCase().includes(searchString));
            });
            appsContainer.innerHTML = this.displayApps(filteredApps);
        } else {
            appDrawerMaker.isSearching = false;
            appsContainer.innerHTML = this.displayApps(this.allApplications);
        }
    },
    searchBarMaker: function() {
        const mainDiv = domMaker.init({
                type: "div",
                id: "drawerSearchContainer",
                className: "bg-blur"
            }),
            searchInput = domMaker.init({
                type: "input",
                id: "drawerSearchTextField",
                className: "inputTextField",
                attribute: ["type", "search"],
                attribute2: ["placeholder", "Tìm kiếm ứng dụng .."]
            });
        searchInput.addEventListener("keyup", (e) => this.searchEvent(e));
        mainDiv.appendChild(searchInput);
        return mainDiv;
    },
    checkIfMenuExists: function() {
        let theMenu = document.querySelector(".menuWindow");
        if(theMenu) {
            menu.closeMenu();
        }
    },
    makeMenu: function(element) {
        appId = element.getAttribute('identifier');
        menu.init({
            id: appId + ".Menu",
            message: api.apps.applicationForIdentifier(appId).name,
            menuItems: [
                {
                    id: "addApp",
                    title: "Đưa ra Màn hình",
                    callback: function() {
                        appDrawerMaker.invokeMenu = false;
                        localstore.addAppObj("metroTiles", {identifier: appId, tileSize: "medium", color: "bg-custom"});
                        startScreenMaker.init(api.apps, api.media);
                    }
                },
                {
                    id: "closeMenu",
                    title: "Huỷ",
                    callback: function() {
                        appDrawerMaker.invokeMenu = false;
                    }
                }
            ]
        });
    },
    animateIcon: function(on, bundle) {
        if(bundle) {
            var grow = 0.95,
                standard = 1.0,
                el = document.getElementById(bundle);
    
            el.style.transition = "transform 150ms ease-in-out";
    
            if(on) {
                el.style.transform = "scale(" + grow + ")";
                el.style.zIndex = "2";
                el.style.webkitTransform = "scale(" + grow + ")";
            } else {
                el.style.transform = "scale(" + standard + ")";
                el.style.zIndex = "2";
                el.style.webkitTransform = "scale(" + standard + ")";
            }
        }
    },
    animateApp: function(el) {
        if((el.target.className === "application" || el.target.id === "start") && !appDrawerMaker.movedWhilePressing) {
            appDrawerMaker.animateIcon(true, el.target.id);
        }
    },
    openApp: function(bundle, callback) {
        if(bundle && !appDrawerMaker.invokeMenu && !appDrawerMaker.movedWhilePressing && document.getElementById(bundle).classList.contains("application")) {
            api.apps.launchApplication(document.getElementById(bundle).getAttribute('identifier'));
            if(callback) {
                callback();
            }
        }
    },
    tapHoldOnIcon: function(el) {
        if(el.className === "application") {
            appDrawerMaker.invokeMenu = true;
            appDrawerMaker.checkIfMenuExists();
            appDrawerMaker.makeMenu(el);
        }
    },
    displayApps: function(filteredApps) {
        let htmlString = "";
        let alphabeticFilter = filteredApps.reduce((r,e) => {
            let alphabet;
            let regExp = /\d+/;
            if(e.name[0] === "\u200e") {
                alphabet = e.name[1];
            } else if(e.name[0] === "\u2800" || regExp.test(e.name[0])) {
                alphabet = "#";
            } else {
                alphabet = e.name[0];
            }
            if (!r[alphabet]) {
                r[alphabet] = { alphabet, record: [e] }
            } else {
                r[alphabet].record.push(e);
            }
            return r;
        }, {});
        let loopVar = Object.values(alphabeticFilter);
        for(let i = 0; i < loopVar.length; i++) {
            if(!this.isSearching) {
                htmlString += `<div id='${loopVar[i].alphabet}' class='alphabeticalOrder'>
                                ${loopVar[i].alphabet}
                            </div>`
            }
            for(let j = 0; j < loopVar[i].record.length; j++) {
                let color = "bg-custom bg-blur";
                let icon = globalParams.mifIcons[loopVar[i].record[j].identifier] ? 
                            `<span class="${globalParams.mifIcons[loopVar[i].record[j].identifier]} icon"></span>` 
                            : `<span class='custom icon' style='background-image: url(${loopVar[i].record[j].icon})'></span>`;
                htmlString += `<div id='${loopVar[i].record[j].identifier}Applist' identifier='${loopVar[i].record[j].identifier}' class='application'>
                                     <div data-role='tile' data-size="small" class="${color} appBG">
                                         ${icon}
                                     </div>
                                     <div class='applicationName'>
                                         ${loopVar[i].record[j].name}
                                     </div>
                             </div>`
            }
        }
        return htmlString;
    },
    allAppsContainer: function() {
        const mainDiv = domMaker.init({
            type: "div",
            id: "allApps"
        });
        mainDiv.innerHTML = this.displayApps(this.allApplications);
        return mainDiv;
    },
    alphabetMaker: function() {
        if(!this.isSearching) {
            let htmlString = "";
            let alphabeticFilter = this.allApplications.reduce((r,e) => {
                let alphabet;
                let regExp = /\d+/;
                if(e.name[0] === "\u200e") {
                    alphabet = e.name[1];
                } else if(e.name[0] === "\u2800" || regExp.test(e.name[0])) {
                    alphabet = "#";
                } else {
                    alphabet = e.name[0];
                }
                if (!r[alphabet]) {
                    r[alphabet] = { alphabet, record: [e] }
                } else {
                    r[alphabet].record.push(e);
                }
                return r;
            }, {});
            let loopVar = Object.values(alphabeticFilter);
            for(let i = 0; i < loopVar.length; i++) {
                htmlString += `<div id='${loopVar[i].alphabet}-goto' class='alphabetF'>
                                    ${loopVar[i].alphabet}
                                </div>`
            }
            const mainDiv = domMaker.init({
                type: "div",
                id: "scrollHelper",
                className: "goToAlphabet hidden",
                innerHTML: htmlString
            });
            mainDiv.addEventListener("touchend", (el) => {
                let scrollTo = document.getElementById(el.target.id[0]);
                scrollTo.parentNode.scroll({
                    top: scrollTo.offsetTop - scrollTo.parentNode.offsetTop,
                    behaviour: "smooth"
                })
                mainDiv.classList.add("hidden");
                setTimeout(() => loadWidget.appDrawer.removeChild(document.getElementById("scrollHelper")), 350);
            });
            setTimeout(() => mainDiv.classList.remove("hidden"), 350);
            loadWidget.appDrawer.appendChild(mainDiv);
        }
    },
    init: function(){
        let searchBarMaker = this.searchBarMaker();
        let appDisplay = this.allAppsContainer();
        domMaker.domAppender({
            div: loadWidget.appDrawer,
            children: [searchBarMaker, appDisplay]
        })
    }
}