var weatherTileMaker = {
    weatherData: function(newData) {
        const content = `<div id="weather2" class="slide">
                            <span class='${globalParams.mifWeather[newData.now.condition.code]} icon'></span>
                        </div>
                        <div id="weather1" class="slide">
                            ${newData.now.temperature.current}°${newData.units.temperature}
                        </div>
                        <div id="weather3" class="slide">
                            ${newData.now.condition.description}
                        </div>
                        <span class="branding-bar">${api.apps.applicationForIdentifier("com.apple.weather").name}</span>`;
        return content;
    },
    init: function(params) {
        let content = this.weatherData(params.newData);
        let color = params.color === "bg-custom" ? "bg-custom bg-blur" : params.color + " bg-blur";
        if(!document.getElementById("com.apple.weather")) {
            const htmlString = `<div name="${api.apps.applicationForIdentifier("com.apple.weather").name}" id="com.apple.weather" data-size="${params.tileSize}" data-role="tile" class="leTile leWeatherTile ${color}" data-effect="slide-up">
                                ${content}
                            </div>`;
            loadWidget.startMenu.innerHTML += htmlString;
        } else {
            document.getElementById("com.apple.weather").innerHTML = content;
        }
    }
}