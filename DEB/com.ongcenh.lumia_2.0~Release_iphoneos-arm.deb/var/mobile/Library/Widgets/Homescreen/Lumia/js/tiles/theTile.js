var tileMaker = {
    init: function(params) {
        let color = params.color === "bg-custom" ? "bg-custom bg-blur" : params.color + " bg-blur";
        let icon = "";
        if(config.disableWidgetIcons) {
            icon = `<span class='custom icon' style='background-image: url(${params.newData.applicationForIdentifier(params.identifier).icon})'></span>`;
        } else {
            icon = globalParams.mifIcons[params.identifier] ? 
            `<span class="${globalParams.mifIcons[params.identifier]} icon"></span>` 
            : `<span class='custom icon' style='background-image: url(${params.newData.applicationForIdentifier(params.identifier).icon})'></span>`
        }
        let badge = params.newData.applicationForIdentifier(params.identifier).badge === "" ? "" : `<span class="badge-top">${params.newData.applicationForIdentifier(params.identifier).badge}</span>`;
        let name = params.size === "small" ? "" : params.newData.applicationForIdentifier(params.identifier).name;
        const htmlString = `<div name="${params.newData.applicationForIdentifier(params.identifier).name}" id="${params.identifier}" data-size="${params.size}" data-role="tile" class="leTile ${color}">
                                ${icon}
                                <span class="branding-bar">${name}</span>
                                ${badge}
                            </div>`;
        loadWidget.startMenu.innerHTML += htmlString;
    } 
}