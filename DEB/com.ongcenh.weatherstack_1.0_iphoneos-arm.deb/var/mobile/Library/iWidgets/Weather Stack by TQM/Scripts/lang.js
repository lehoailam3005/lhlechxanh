var current = (window.navigator.language.length >= 2) ? window.navigator.language.split('-')[0] : 'en',
    $$ = function (el) {
        return document.getElementById(el);
    },
    translate = {
        vi: {
            sday: ["Chủ nhật","Thứ hai","Thứ ba","Thứ tư","Thứ năm","Thứ sáu","Thứ bảy"],
            weekday: ["C.N","T.2","T.3","T.4","T.5","T.6","T.7"],
            month: ["Tháng 1","Tháng 2","Tháng 3","Tháng 4","Tháng 5","Tháng 6","Tháng 7","Tháng 8","Tháng 9","Tháng 10","Tháng 11","Tháng 12"],
            smonth: ["Tháng 1","Tháng 2","Tháng 3","Tháng 4","Tháng 5","Tháng 6","Tháng 7","Tháng 8","Tháng 9","Tháng 10","Tháng 11","Tháng 12"],

            condition: ["Lốc tố", "Bão nhiệt đới", "Có bão", "Có giông", "Có giông", "Tuyết rơi", "Mưa đá", "Mưa đá", "Mưa phùn", "Mưa phùn", "Trời lạnh", "Có mưa", "Có mưa", "Đang mưa", "Có bão", "Tuyết rơi", "Tuyết rơi", "Tuyết rơi", "Mưa đá", "Mưa đá", "Mưa bay", "Sương mù", "Sương mù", "Sương mù", "Gió mạnh", "Có gió", "Trời lạnh", "Nhiều mây", "Nhiều mây", "Nhiều mây", "Nhiều mây", "Nhiều mây", "Trời quang", "Trời đẹp", "Trời trong", "Trời trong", "Mưa đá", "Trời nóng", "Sấm sét", "Sấm sét", "Sấm sét", "Có mưa", "Tuyết rơi", "Tuyết rơi", "Tuyết rơi", "Ít mây", "Có giông", "Có giông", "Có giông", "blank"]
        },
        en: {
            sday: ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
            weekday: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
            month: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
            smonth: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
            condition: ["Tornado", "Tropical Storm", "Hurricane", "Thunderstorm", "Thunderstorm", "Snow", "Sleet", "Sleet", "Freezing Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "Thunderstorms", "Thunderstorms", "Thunderstorms", "Showers", "Heavy Snow", "Light Snow", "Heavy Snow", "Partly Cloudy", "Thunderstorm", "Snow", "Thunderstorm", "blank"]
        }
    };
if (!translate[current]) {
    current = 'en';
}
