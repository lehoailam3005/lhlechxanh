function cvtSun(time) {
  var timecut, timeE, amm, cvtt;
  if (String(time).length > 3) {
    timecut = String(time).slice(0, 2);
    timeE = String(time).slice(2, 4);
  } else {
    timeE = String(time).slice(1, 3);
    timecut = String(time).slice(0, 1);
  }
  if (timecut === "00") {
    return 12;
  }
  amm = (timecut > 11) ? " pm" : " am";
  cvtt = (timecut > 12) ? timecut - 12 : timecut;
  return cvtt + ":" + timeE + amm;
};
function cvtSunt(time) {
  var timecut, timeE, amm, cvtt;
  if (String(time).length > 3) {
    timecut = String(time).slice(0, 2);
    timeE = String(time).slice(2, 4);
  } else {
    timeE = String(time).slice(1, 3);
    timecut = String(time).slice(0, 1);
  }
  cvtt = timecut;
  return cvtt + ":" + timeE;
};




