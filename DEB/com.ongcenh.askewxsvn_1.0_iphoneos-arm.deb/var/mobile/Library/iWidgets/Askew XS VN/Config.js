var AMPM = false; // Bật tắt "AM" , "PM"
var TQM = true; // Định dạng "24h" , "12h"
var NhapTen = "Xin Chào Quang Minh"; // Ký tự tuỳ chỉnh
var Mauchu = "#fff"; // Màu chữ
var Goithoitiet = "2"; // Gói thời tiết "1","2","3"
var NenMo = true; // Nền mờ
var AnNen = false; // Ẩn nền
var MauNen = "#fff"; // Màu nền tuỳ chỉnh
