# Phiên bản mã hóa nguồn mở
# Copyright (C) 2021 TQM - Mos
# Phiên bản v1.0~b3
# Gõ lệnh cloneapp <app> để chạy