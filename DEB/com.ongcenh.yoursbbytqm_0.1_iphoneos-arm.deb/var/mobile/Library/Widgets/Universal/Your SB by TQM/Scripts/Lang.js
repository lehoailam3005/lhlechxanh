var twentyfourhour = true; //false
var pad = true; //true

var current = (window.navigator.language.length >= 2) ? window.navigator.language.split('-')[0] : 'vi',
    $$ = function (el) {
        return document.getElementById(el);
    },
    translate = {
        vi: {
            weekday: ["CN","Thứ 2","Thứ 3","Thứ 4","Thứ 5","Thứ 6","Thứ 7"],
            sday: ["CN","Thứ 2","Thứ 3","Thứ 4","Thứ 5","Thứ 6","Thứ 7"],
            month: ["Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 1 0", "Tháng 1 1", "Tháng 1 2"],
            smonth: ["Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 1 0", "Tháng 1 1", "Tháng 1 2"],
             condition : ["C ó L ố c t ố", "C ó B ã o n h i ệ t đ ớ i", "T r ờ i C ó  b ã o", "T r ờ i C ó g i ô n g", "T r ờ i C ó g i ô n g", "C ó T u y ế t r ơ i", "C ó M ư a đ á", "C ó M ư a đ á", "C ó M ư a p h ù n", "C ó M ư a p h ù n", "T r ờ i l ạ n h", "T r ờ i C ó m ư a", "T r ờ i C ó m ư a", "T r ờ i Đ a n g m ư a", "T r ờ i C ó b ã o", "C ó T u y ế t r ơ i", "C ó T u y ế t r ơ i", "C ó T u y ế t r ơ i", "C ó M ư a đ á", "C ó M ư a đ á", "C ó M ư a b a y", "S ư ơ n g m ù", "C ó S ư ơ n g m ù", "C ó S ư ơ n g m ù", "C ó G i ó l ạ n h", "T r ờ i C ó g i ó", "Trời lạnh", "T r ờ i N h i ề u m â y", "T r ờ i N h i ề u m â y", "T r ờ i N h i ề u m â y", "T r ờ i N h i ề u m â y", "T r ờ i N h i ề u m â y", "T r ờ i q u a n g", "T r ờ i đ ẹ p", "T r ờ i t r o n g", "T r ờ i t r o n g", "C ó M ư a đ á", "T r ờ i n ó n g", "C ó S ấ m s é t", "C ó S ấ m s é t", "C ó S ấ m s é t", "C ó m ư a", "C ó T u y ế t r ơ i", "C ó T u y ế t r ơ i", "C ó T u y ế t r ơ i", "Trời Ít mây", "T r ờ i C ó g i ô n g", "T r ờ i C ó g i ô n g", "T r ờ i C ó g i ô n g", "blank"]
        }
    };
if (!translate[current]) {
    current = 'vi';
}

