var iPhoneType = "auto"; // "iPhG", "iPhPlus" và "iPhX" và "iPhXMax" .Tuỳ chọn các máy ( iPhG = 6/7/8 ) , ( iPhPlus = Các máy Plus ) , ( iPhX và iPhXMax thì không cần nói 🤣

// GET THE CURRENT WIDTH & HEIGHT
if (iPhoneType == "auto") {
	 if (screen.height == 667) { iPhoneType = "iPhG"; }
	else if (screen.height == 736) { iPhoneType = "iPhPlus"; }
	else if (screen.height == 812) { iPhoneType = "iPhX"; }
	else if (screen.height == 896) { iPhoneType = "iPhXMax"; }
	else { iPhoneType = "iPhXMax"; }
}

// RESIZE THE BODY
window.addEventListener("load", function() { 
	switch(iPhoneType) {
		case "iPhG":
			document.body.style.width='375px';
			document.body.style.height='667px';
		break;
		case "iPhPlus":
			document.body.style.width='414px';
			document.body.style.height='736px';
		break;
		case "iPhX":
			document.body.style.width='375px';
			document.body.style.height='812px';
		break;
		case "iPhXMax":
			document.body.style.width='414px';
			document.body.style.height='896px';
		break;
		case "editMode":
			document.body.style.width='563px';
    		document.body.style.height='1000px';
		break;
	}
}, false);

	    // SPECIAL CSS POSITIONING FOR iPHONE X & iPHONE X Max by Tqm-Mos

		$('head').removeAttr('Style');
		if (iPhoneType == 'iPhXMax') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/StyleXMax.css" type="text/css" >');
		}
		else if (iPhoneType == 'iPhX') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/StyleX.css" type="text/css" >');
		}
		else if (iPhoneType == 'iPhG') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/StyleG.css" type="text/css" >');
		}
		else if (iPhoneType == 'iPhPlus') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/StylePlus.css" type="text/css" >');
		}
		else {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/Style.css" type="text/css" >');
	}
