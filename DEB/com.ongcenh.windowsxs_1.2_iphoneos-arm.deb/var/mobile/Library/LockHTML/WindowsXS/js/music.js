function music_overflowing(element) {
	var overflowX = element.offsetWidth < element.scrollWidth, overflowY = element.offsetHeight < element.scrollHeight;
	return (overflowX || overflowY);
}

function wrapContentsInMarquee(element) {
	var marquee = document.createElement('marquee'), contents = element.innerText;
	marquee.innerText = contents;
	element.innerHTML = '';
	element.appendChild(marquee);
}

function mainUpdate(type){
	var title = "This is a Title Test";
	if (type == "music") {
		if (isplaying) {
			document.getElementById('track_title').innerHTML = title;
			document.getElementById('track_artist').innerHTML = artist;
			document.getElementById('track_album').innerHTML = album;
			var track_title = document.getElementById('track_title');
			var track_artist = document.getElementById('track_artist');
			var track_artist = document.getElementById('track_album');

			if (music_overflowing(track_title)) {
				wrapContentsInMarquee(track_title);
			}
			if (music_overflowing(track_artist)) {
				wrapContentsInMarquee(track_artist);
			}
			if (music_overflowing(track_artist)) {
				wrapContentsInMarquee(track_artist);
			}

			var milli = new Date().getMilliseconds(),
			url = "/var/mobile/Documents/Artwork.jpg?" + milli;
			document.getElementById("artwork").innerHTML = "<img class='music_image_size' src='"+url+"'>"
			ShowPause();
		} else {
			//document.getElementById('track_title').innerHTML = "No Music Playing";
			//document.getElementById('track_artist').innerHTML = "Artist Unavailable";
			//document.getElementById('track_album').innerHTML = "Album Unavailable";
			//document.getElementById("artwork").innerHTML = "<img class='music_image_size' src='images/ArtworkDefault.jpg'>"
			ShowPlay()
		}
	}
}

function playPause() {
	window.location = 'xeninfo:playpause';
	console.log("Play");
}
function next() {
	window.location = 'xeninfo:nexttrack';
	console.log("Next");
}
function prev() {
	window.location = 'xeninfo:prevtrack';
	console.log("Previous");
}

function ShowPlay() {
	var element = document.getElementById("playOrPause");
	element.classList.remove("fa-pause");
	element.classList.add("fa-play");
}
function ShowPause() {
	var element = document.getElementById("playOrPause");
	element.classList.remove("fa-play");
	element.classList.add("fa-pause");
}
