function openMail() {
	console.log("openMail");
	window.location = 'xeninfo:openapp:com.apple.mobilemail';
}
function openMessages() {
	console.log("openMessages");
	window.location = 'xeninfo:openapp:com.apple.MobileSMS';
}
function openSafari() {
	console.log("openSafari");
	window.location = 'xeninfo:openapp:com.apple.mobilesafari';
}
function openNotepad() {
	console.log("openNotepad");
	window.location = 'xeninfo:openapp:com.apple.mobilenotes';
}
function openFitness() {
	console.log("openFitness");
	window.location = 'xeninfo:openapp:com.apple.Fitness';
}
function openFiles() {
	console.log("openFiles");
	window.location = 'xeninfo:openapp:com.apple.DocumentsApp';
}
function openPhotos() {
	console.log("openPhotos");
	window.location = 'xeninfo:openapp:com.apple.mobileslideshow';
}
function openMusic() {
	console.log("openMusic");
	window.location = 'xeninfo:openapp:com.apple.Music';
}
function openAppStore() {
	console.log("openAppStore");
	window.location = 'xeninfo:openapp:com.apple.AppStore';
}
function openPC() {
	console.log("openPC");
	window.location = 'xeninfo:openapp:com.apple.Preferences';
}
function openNetwork() {
	console.log("openNetwork");
	window.location = 'xeninfo:openapp:com.apple.Preferences';
}
function openShortcuts() {
	console.log("openShortcuts");
	window.location = 'xeninfo:openapp:is.workflow.my.app';
}
function openSearch() {
	console.log("openSearch");
	window.location = 'xeninfo:openspotlight';
}
function openRun() {
	console.log("openRun");
	window.location = 'xeninfo:openapp:ws.hbang.Terminal';
	window.location = 'xeninfo:openapp:ws.hbang.newterm2';
}
function openTime() {
	console.log("openTime");
	window.location = 'xeninfo:openapp:com.apple.mobiletimer';
}
function openPhone() {
	console.log("openPhone");
	window.location = 'xeninfo:openapp:com.apple.mobilephone';
}
function openTrash() {
	console.log("openTrash");
	window.location = 'xeninfo:openapp:org.coolstar.chimera';
	window.location = 'xeninfo:openapp:org.coolstar.electra';
}
