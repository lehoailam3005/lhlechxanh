
// Dismiss start menu when desktop clicked
$('.screen').click(function(e){
	console.log("Screen Clicked");
	if($(e.target).hasClass('screen')) {
		$('#start-menu-active').prop('checked', false);
		$('#wifi').hide();
		$('#battery').hide();
		$('#time_date').hide();
		$('#signal').hide();
	}
});


// test
$('.start-button').click(function(e){
	console.log("hello ms jackson");
    $('#wifi').hide();
    $('#battery').hide();
    $('#time_date').hide();
    $('#signal').hide();
});
