function AllProgramsFunction() {
	var x = document.getElementById("start-menu-shortcuts_hidden");
	var x2 = document.getElementById("start-menu-favorites");
	var x3 = document.getElementById("start-menu");

  	if (x.classList.contains("start-menu-shortcuts_hidden")) {
		x2.classList.remove("set_100");
		x2.classList.add("set_50");
		x3.classList.add("start_menu_large");
		x.classList.remove("start-menu-shortcuts_hidden");
  	} else {
		x.classList.add("start-menu-shortcuts_hidden");
		x2.classList.add("set_100");
		x2.classList.remove("set_50");
		x3.classList.remove("start_menu_large");
  	}
}
function BatteryFunction() {
	ResetDefaults();
  	var x = document.getElementById("battery");
  	if (x.style.display === "none") {
    		x.style.display = "inherit";
		x.style.right = "50";
		//x.style.zIndex = "100000";
  	} else {
    		x.style.display = "none";
  	}
}

function DateFunction() {
	ResetDefaults();
  	var x = document.getElementById("time_date");
  	if (x.style.display === "none") {
    		x.style.display = "inherit";
		//x.style.zIndex = "100000";
  	} else {
    		x.style.display = "none";
  	}
}
function WiFiFunction() {
	ResetDefaults();
  	var x = document.getElementById("wifi");
  	if (x.style.display === "none") {
		x.style.right = "80";
    		x.style.display = "inherit";
		//x.style.zIndex = "100000";
  	} else {
    		x.style.display = "none";
  	}
}

function SignalFunction() {
	ResetDefaults();
  	var x = document.getElementById("signal");
  	if (x.style.display === "none") {
		x.style.right = "110";
    		x.style.display = "inherit";
		//x.style.zIndex = "100000";
  	} else {
    		x.style.display = "none";
  	}
}

function ResetDefaults() {
	document.getElementById("battery").style.display = "none";
	document.getElementById("time_date").style.display = "none";
	document.getElementById("wifi").style.display = "none";
	document.getElementById("signal").style.display = "none";
	
	//document.getElementById("BSOD").style.display = "none";
	//$('#start-menu-active').prop('checked', false);

}

function HideMusic() {
	document.getElementById("music_container").style.display = "none";
}

function HideWeather() {
	document.getElementById("weather_container").style.display = "none";
}

function MusicFunction() {
	ResetDefaults();
	var x = document.getElementById("music_container");
  	if (x.style.display === "none") {
		x.style.right = "110";
    		x.style.display = "block";
  	} else {
    		x.style.display = "none";
  	}
}

function BSODFunction() {
	ResetDefaults();
	var x = document.getElementById("BSOD");
  	if (x.style.display == "unset") {
    		x.style.display = "none";
  	} else {
   		x.style.display = "unset";
		window.location = 'xeninfo:openurl:twitter.com/AppzAussie';
		console.log("Opening AussieAppz");
	}
}

function WeatherFunction() {
	ResetDefaults();
	var x = document.getElementById("weather_container");
  	if (x.style.display === "unset") {
    		x.style.display = "none";
  	} else {
    		x.style.display = "unset";
  	}
}

function SetZIndexW() {
	document.getElementById("weather_container").style.zIndex = "2";
	document.getElementById("music_container").style.zIndex = "1";
}

function SetZIndexM() {
	document.getElementById("weather_container").style.zIndex = "1";
	document.getElementById("music_container").style.zIndex = "2";
}
