//Set details for icon 1

document.getElementById("icon_1_image").innerHTML = "<img class='desktop_icons' src=" + App1Icon + ">";
document.getElementById("icon_1_label").innerHTML = App1Name;
document.getElementById("icon_1_click").addEventListener('click', 
	function(){ 
		window.location = 'xeninfo:openapp:' + App1BundleID;
		console.log("Opening " + App1BundleID);
	}
, false);
//Set details for icon 2

if (icon_2_label != "") {
	document.getElementById("icon_2_image").innerHTML = "<img class='desktop_icons' src=" + App2Icon + ">";
	document.getElementById("icon_2_label").innerHTML = App1Name;
	document.getElementById("icon_2_click").addEventListener('click', 
	function(){ 
		window.location = 'xeninfo:openapp:' + App2BundleID;
		console.log("Opening " + App2BundleID);
	}
	, false);
}