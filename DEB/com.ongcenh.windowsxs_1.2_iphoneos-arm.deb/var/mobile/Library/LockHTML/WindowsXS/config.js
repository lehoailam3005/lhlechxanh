var LoginName = "Welcome Back";
var LoginImage = "images/duck.gif";

var App1Icon = "images/phone.png";
var App1Name = "Phone";
var App1BundleID = "com.apple.mobilephone";

var App2Icon = "images/safari.png";
var App2Name = "Safari";
var App2BundleID = "com.apple.mobilesafari";

var App3Icon = "images/messages.png";
var App3Name = "Messages";
var App3BundleID = "com.apple.MobileSMS";

var App4Icon = "";
var App4Name = "";
var App4BundleID = "";

var App5Icon = "";
var App5Name = "";
var App5BundleID = "";

var App6Icon = "";
var App6Name = "";
var App6BundleID = "";
