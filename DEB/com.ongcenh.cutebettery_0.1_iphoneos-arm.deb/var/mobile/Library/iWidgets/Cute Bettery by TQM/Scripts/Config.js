var twentyfourhour = true;
var pad = true;
var IconSet = "icon"; // Không thay đổi



