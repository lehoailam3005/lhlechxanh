/**
 * Created by artzub on 08.09.2014.
 */

"use strict";

var sky = document.querySelector("#sky")
    , ctx = sky.getContext("2d")
    , w, h
    , pi180 = Math.PI/180
    , particles = []
    , planes = []
    , valid = false
    , settings = {
        amount : 200
        , bunch : 5
        , maxRadius : 4
        , minRadius : 3
        , particleDisp : 10
        , life : 450 //ticks
        , planeAmount : 1
        , planeSize : 40
        , planeMaxSpeed : 3
        , planeSizeMin : 30
        , planeLife : 0
        , partColor : [255, 255, 255]
        , planeColor : [244, 244, 244]
        , reset : function() {
            planes.splice(0);
            particles.splice(0);
        }
    }
    , cloud =
        //generateCloud(32, 32, 255, 255, 255, 1) //canvas_utils.colorize(canvas_utils.resources.images.particle, 255, 255, 255, 1)
        canvas_utils.generateNeonBall(32, 32, settings.partColor[0], settings.partColor[1], settings.partColor[2], 1)
    , planeImg = getPlaneImage()
    , plane = canvas_utils.colorize(planeImg, settings.planeColor[0], settings.planeColor[1], settings.planeColor[2], 1)
    ;

function generateCloud(w, h) {
    var tempCanvas = document.createElement("canvas");

    tempCanvas.width = w;
    tempCanvas.height = h;

    var imgCtx = tempCanvas.getContext("2d");
    var gradient = imgCtx.createRadialGradient( w/2, h/2, 0, w/2, h/2, w/2 );

    gradient.addColorStop(0, 'rgba(' + [255, 255, 255, a] + ')');
    gradient.addColorStop(0.2, 'rgba(' + [255, 255, 255, a * .5] + ')');
    gradient.addColorStop(1, 'rgba(' + [255, 255, 255, 0] + ')');

    imgCtx.fillStyle = gradient;
    imgCtx.fillRect(0, 0, w, h);

    return tempCanvas;
}

function unsigRand(max, min) {
    min = min || 0;
    var m = max > min ? max : min;
    min = max == m ? min : max;
    max = m;

    return ((Math.random() * (max - min)) + min) | 0;
}

function rand(to) {
    var r = Math.random() * 10 * 2 - 10 | 0;
    return unsigRand(to) * (r/Math.abs(r));
}

function Particle(x, y, r, target) {
    this.x = x;
    this.y = y;
    this.r = r || 5;
    this.life = settings.life;
    this.coff = 1;

    this.target = target;
    target.x += this.r * rand(2);
    target.y += this.r * rand(2);
}

Particle.prototype.update = function() {
    var dx = this.x - this.target.x
        , dy = this.y - this.target.y
        , r = Math.sqrt(Math.pow(dx, 2) + Math.pow(dy, 2))
        ;
    if (r != this.r) {
        r = (r - this.r) / (r || 1) * .015;
        this.x -= dx * r;
        this.y -= dy * r;
    }

    if (this.coff > 0 && settings.life && this.life-- < 0) {
        this.coff = -10;
    }
    this.killed = this.r <= 0;
    this.r += .05 * this.coff;
    this.r = this.r > 0 ? this.r : 0;
};

Particle.prototype.draw = function(ctx) {
    var s = this.r
        , s2 = s/2
        ;
    ctx.drawImage(cloud, this.x - s2, this.y - s2, s, s);
};

function Plane(x, y, r) {
    this.x = x;
    this.y = y;
    this.r = r;
    this.vx = rand(settings.planeMaxSpeed) || 1;
    this.vy = this.vx * (rand(1) || -1);
    this.life = settings.planeLife;

    //dirty hack =)
    this.angle = Math.atan2(this.vy, this.vx) + 1.57;
}

Plane.prototype.update = function() {
    this.x += this.vx;
    this.y += this.vy;
    
    var r2 = this.r/2;

    if (this.x < -r2 || this.x > w + r2) {
        //this.vx *= -1;
        this.x = this.x > 0 ? 0 : w;
    }
    if (this.y < -r2 || this.y > h + r2) {
        //this.vy *= -1;
        this.y = this.y > 0 ? 0 : h;
    }

    this.angle = Math.atan2(this.vy, this.vx) + 1.57;

    this.killed = this.killed && settings.planeLife && this.life-- < 0;
    if (this.killed)
        return;

    //TODO fix trouble with coords of jets
    var l = settings.bunch
        , gr = this.r/6
        , x, y, x2, y2, x1, y1
        , rrr = 1
        ;
    while(l--) {
        x = this.x + (this.r/3.5)*(-this.vx/(Math.abs(this.vx) || 1));
        y = this.y + (this.r/3.5)*(-this.vy/(Math.abs(this.vy) || 1));
        
        x1 = this.vx > 0 ? gr : -gr;
        y1 = this.vy > 0 ? -gr : gr;
        appendParticle({
            x : x + x1, y : y + y1
        }, {
            x : x + rand(settings.particleDisp) + x1 * rrr,
            y : y + rand(settings.particleDisp) + y1 * rrr
        });
      
        x2 = this.vx > 0 ? -gr : gr;
        y2 = this.vy > 0 ? gr : -gr;

        appendParticle({
            x : x + x2, y : y + y2
        }, {
            x : x + rand(settings.particleDisp) + x2 * rrr,
            y : y + rand(settings.particleDisp) + y2 * rrr
        });
    }

};

Plane.prototype.draw = function(ctx) {
    var s = this.r
        , s2 = s/2
        ;
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(this.angle);
    ctx.drawImage(plane, -s2, -s2, s, s);
    ctx.restore();
};

function anim() {
    requestAnimationFrame(anim);

    if (valid)
        return;

    valid = true;

    w = window.innerWidth;
    h = window.innerHeight;

    if (sky.width != w) {
        sky.width = w;
    }
    if (sky.height != h) {
        sky.height = h;
    }

    planes.length < settings.planeAmount && appendPlane({
        x : 0, y : unsigRand(h, 0)
    });
  
    ctx.globalCompositeOperation = 'source-over';
    ctx.clearRect(0, 0, w, h);    
    ctx.drawImage(drawParticles(w, h), 0, 0);
    ctx.drawImage(drawPlanes(w, h), 0, 0);

    valid = false;
}

var cps = document.createElement('canvas')
    , ctxPs = cps.getContext('2d')
    ;

function drawParticles(w, h) {

    if (cps.width != w) {
        cps.width = w;
    }
    if (cps.height != h) {
        cps.height = h;
    }

    ctxPs.save();

    ctxPs.globalCompositeOperation = 'destination-out';
    ctxPs.fillStyle = 'rgba(0, 0, 0, .1)';
    ctxPs.fillRect(0, 0, w, h);
    ctxPs.globalCompositeOperation = 'lighter';

    var l = particles.length
        , item
        ;
    while(l--) {
        item = particles[l];
        item.draw(ctxPs);
        item.update();
        if (item.killed)
            particles.splice(particles.indexOf(item), 1);
    }

    ctxPs.restore();

    return cps;
}

var cplns = document.createElement('canvas')
    , ctxPlns = cps.getContext('2d')
    ;

function drawPlanes(w, h) {

    if (cplns.width == w) {
        cplns.width = w;
    }
    if (cplns.height == h) {
        cplns.height = h;
    }

    ctxPlns.save();

    ctxPlns.globalCompositeOperation = 'destination-out';
    ctxPlns.fillStyle = 'rgb(0, 0, 0)';
    ctxPlns.fillRect(0, 0, w, h);
    ctxPlns.globalCompositeOperation = 'source-over';
    
    var l = planes.length
        , item
        ;
    while(l--) {
        item = planes[l];
        item.draw(ctxPlns);
        item.update();
        if (item.killed)
            planes.splice(planes.indexOf(item), 1);
    }
    if (planes.length > settings.planeAmount)
        planes.splice(0, planes.length > settings.planeAmount);

    ctxPlns.restore();

    return cplns;
}

function appendParticle(from, target) {
    particles.push(new Particle(from.x, from.y, unsigRand(settings.maxRadius, settings.minRadius), target));
}

function appendPlane(from, target) {
    planes.push(new Plane(from.x, from.y, unsigRand(settings.planeSize, settings.planeSizeMin), target));
}

function hexToRgbArray(value) {
  return [
    parseInt(value.substring(1,3),16)
    , parseInt(value.substring(3,5),16)
    , parseInt(value.substring(5,7),16)
  ];
}

!function() {
    var gui = new dat.GUI({
        load : JSON
        , preset : 'Default'
    });
  
    function onColorChange(value) {
      console.log(value);
      if (typeof value === 'string') {
          value = hexToRgbArray(value);
      }
      cloud = canvas_utils.generateNeonBall(32, 32, value[0] | 0, value[1] | 0, value[2] | 0, 1);
    }
  
    function onPlaneColorChange(value) {
      console.log(value);
      if (typeof value === 'string') {
          value = hexToRgbArray(value);
      }
      plane = canvas_utils.colorize(planeImg, value[0], value[1], value[2], 1);
    }
    
    var f = gui.addFolder('Particles');
    f.add(settings, 'maxRadius', 1, 50).step(1).listen();
    f.add(settings, 'minRadius', 1, 50).step(1).listen();
    f.add(settings, 'bunch', 0, 50).step(1).listen();
    f.add(settings, 'particleDisp', 0, 50).step(1).listen();
    f.add(settings, 'life', 0, 1000).step(10).listen();
    f.addColor(settings, 'partColor').onChange(onColorChange).listen();
    
    
    f = gui.addFolder('Planes');
    f.add(settings, 'planeAmount', 1, 50).step(1).listen();
    f.add(settings, 'planeSize', 1, 50).step(1).listen();
    f.add(settings, 'planeSizeMin', 1, 50).step(1).listen();
    f.add(settings, 'planeLife', 0, 1000).step(10).listen();
    f.addColor(settings, 'planeColor').onChange(onPlaneColorChange).listen();
    
    gui.add(settings, 'reset');
  
    //gui.add(settings, 'restart');
    gui.remember(settings);
}();

anim();

function getPlaneImage() {
  var img = new Image();
  img.src = '';
  return img;
}